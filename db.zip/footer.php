<!-- membuat footer -->
<footer>
  <p>&copy; 2016, Teknik Informatika Pelita Bangsa</p>
</footer>
</div>

</body>
</html>
