<!-- membuat isi navigasi -->
<nav>
  <ul>
  <li><a href="login.php" title="logout">Logout</a></li>
  <li><a href="index.php" title="artikel">Artikel</a></li>
    <li><a href="home.php" title="home">Home</a></li>
      
  </ul>
</nav>
