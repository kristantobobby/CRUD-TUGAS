<?php
$host ="localhost";
$user ="root";
$pass ="";
$db ="tes_db";

$conn =mysqli_connect($host,$user,$pass,$db);



  ?>
