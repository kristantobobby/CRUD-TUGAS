<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <!-- Google Fonts -->
    <!-- <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,400,700,600" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,300italic,700" rel="stylesheet" type="text/css"> -->

    <!-- berikut adalah pemagilan file .css -->
    <meta name="description" content="" />
    <link href="style.css" type="text/css" rel="stylesheet" />
    <meta name="viewport" content="width=device-widget, initial-scale=1">
    <title>Home</title>
  </head>
  <body>
    <!-- ini adalah container -->
    <div id="container">
      <!-- membuat header -->
      <header>
        <div class="entry">
          <h2>Coding Study</h2>

        </div>
      </header>
