<!DOCTYPE html>
<html lang="en" dir=ltr"">
<head>
	<meta charset="utf-8">
	<!-- Berikut adalah pemanggilan file.css -->
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>Belajar</title>
</head>
<body>
	<!-- Ini adalah container -->
	<div id="container">
		<!-- Membuat Header-->
			<header>
			<center>
				<h1>CODING STUDY</h1>
			</center>
			</header>
		